/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.8.3+os161-2.1/configure --enable-languages=c,lto --nfp --disable-shared --disable-threads --disable-libmudflap --disable-libssp --disable-libstdcxx --disable-nls --target=mips-harvard-os161 --prefix=/opt/os161/tools --with-gmp=/opt/os161/gmp --with-mpfr=/opt/os161/mpfr --with-mpc=/opt/os161/mpc";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
